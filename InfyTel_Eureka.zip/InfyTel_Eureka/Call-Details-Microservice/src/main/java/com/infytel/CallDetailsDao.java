package com.infytel;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface CallDetailsDao extends CrudRepository<CallDetails, Long>{

	List<CallDetails> findAll();
}
