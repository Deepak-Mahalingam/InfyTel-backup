package com.infytel;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface CustomerDao extends CrudRepository<Customer, Long> {
	
	List<Customer> findAll();
	Customer getCustomerByPhoneNo(Long phoneNo);
	
}
