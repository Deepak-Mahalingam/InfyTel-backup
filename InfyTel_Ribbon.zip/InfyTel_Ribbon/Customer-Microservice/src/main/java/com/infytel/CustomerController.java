package com.infytel;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.ribbon.ServerIntrospector;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@EnableAutoConfiguration
@RefreshScope
public class CustomerController {
	@Autowired RestTemplate template;
	
	@Autowired CustomerDao customerDao;

	
	@RequestMapping(value="/customers")
	public List<Customer> getAllCustomers(){
		return customerDao.findAll();
	}

	@RequestMapping(value="/customers/{phoneNo}")
	public CustomerDTO getCustomerByPhoneNo(@PathVariable Long phoneNo){

		System.out.println("==== Customer phone number is ==== "+phoneNo);
		CustomerDTO customerDto = new CustomerDTO();
		Customer c=customerDao.getCustomerByPhoneNo(phoneNo);
		customerDto.setAge(c.getAge());
		customerDto.setGender(c.getGender());
		customerDto.setName(c.getName());
		customerDto.setCustomerId(c.getCustomerId());
		customerDto.setPhoneNo(c.getPhoneNo());
		
		
		
		List<Long> friends=template.getForObject("http://FriendMS/friends/"+phoneNo, List.class);
		customerDto.setFriendAndFamily(friends);
		
		return customerDto;

	}






	@RequestMapping(value="/newcustomer",method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void newCustomer(@RequestBody Customer customer){
		customerDao.save(customer);
	}

}
